"use client";
import React, { useState, useEffect, useMemo } from 'react';
import {
  Activity, Users, Plus, X, CheckCircle2, User, AlertCircle, 
  Thermometer, HeartPulse, Wind, Edit3, Trash2, ShieldAlert, Hotel
} from 'lucide-react';

// --- MODAL COMPONENT ---
const Modal = ({ title, children, onClose }: { title: string, children: React.ReactNode, onClose: () => void }) => (
  <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/60 backdrop-blur-md p-4 animate-in fade-in duration-300">
    <div className="bg-white rounded-3xl shadow-2xl w-full max-w-2xl max-h-[90vh] overflow-hidden flex flex-col border-4 border-slate-900 scale-in-center">
      <div className="flex justify-between items-center p-6 border-b-4 border-slate-100 bg-slate-50/50">
        <h2 className="text-xl font-black text-slate-800 uppercase tracking-tight">{title}</h2>
        <button onClick={onClose} className="p-2 hover:bg-slate-200 rounded-full transition-colors border-2 border-transparent hover:border-slate-300">
          <X className="w-5 h-5 text-slate-500" />
        </button>
      </div>
      <div className="p-6 overflow-y-auto flex-1">{children}</div>
    </div>
  </div>
);

const HMSOnePage = () => {
  const [activeModal, setActiveModal] = useState<string | null>(null);
  const [selectedPatient, setSelectedPatient] = useState<any>(null);
  const [showNotification, setShowNotification] = useState(false);
  const [patientsList, setPatientsList] = useState<any[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formData, setFormData] = useState({
    name: "", age: "", gender: "Male", bloodGroup: "O+", triage: "Level 3 - Routine",
    ward: "Ward B (General)", temp: "98.6", bp: "120/80", pulse: "72", spO2: "98"
  });

  const fetchData = async () => {
    try {
      const res = await fetch('/api/patients');
      const data = await res.json();
      setPatientsList(data);
    } catch (error) {
      console.error("Error fetching data:", error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => { fetchData(); }, []);

  // --- CALCULATED STATS FROM BACKEND DATA ---
  const derivedStats = useMemo(() => {
    const criticalCount = patientsList.filter(p => {
      const spO2 = parseInt(p.vitals?.spO2 || "100");
      const bpSys = parseInt(p.vitals?.bp?.split('/')[0] || "120");
      return spO2 < 92 || bpSys > 140; // Logic for "Critical"
    }).length;

    const wardCounts: Record<string, number> = {};
    patientsList.forEach(p => {
      if (p.ward) wardCounts[p.ward] = (wardCounts[p.ward] || 0) + 1;
    });
    const busiestWard = Object.entries(wardCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || "N/A";

    return [
      { title: "Total Patients", count: patientsList.length, icon: <Users />, id: 'patients', color: 'indigo', sub: "Active Registry" },
      { title: "Critical Alerts", count: criticalCount, icon: <ShieldAlert />, id: 'critical', color: 'rose', sub: "Unstable Vitals" },
      { title: "Peak Occupancy", count: busiestWard, icon: <Hotel />, id: 'ward-stat', color: 'amber', sub: "Busiest Ward" },
    ];
  }, [patientsList]);

  const startEdit = (patient: any) => {
    setFormData({
      name: patient.name, age: patient.age || "", gender: patient.gender || "Male",
      bloodGroup: patient.bloodGroup || "O+", triage: patient.admissionType || "Level 3 - Routine",
      ward: patient.ward || "Ward B (General)", temp: patient.vitals?.temp || "98.6",
      bp: patient.vitals?.bp || "120/80", pulse: patient.vitals?.pulse || "72", spO2: patient.vitals?.spO2 || "98"
    });
    setEditingId(patient._id);
    setActiveModal('new-patient');
  };

  const handleSave = async () => {
    if (!formData.name || !formData.age) return alert("Please fill Name and Age");
    const method = editingId ? 'PATCH' : 'POST';
    const payload = {
      id: editingId, name: formData.name, age: parseInt(formData.age) || 0,
      gender: formData.gender, bloodGroup: formData.bloodGroup, admissionType: formData.triage,
      ward: formData.ward, status: 'In-Patient',
      vitals: { temp: formData.temp, bp: formData.bp, pulse: formData.pulse, spO2: formData.spO2 }
    };

    try {
      const res = await fetch('/api/patients', {
        method, headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload),
      });
      if (res.ok) {
        setFormData({ name: "", age: "", gender: "Male", bloodGroup: "O+", triage: "Level 3 - Routine", ward: "Ward B (General)", temp: "98.6", bp: "120/80", pulse: "72", spO2: "98" });
        setEditingId(null);
        await fetchData();
        setActiveModal(null);
        setShowNotification(true);
        setTimeout(() => setShowNotification(false), 3000);
      }
    } catch (error) { console.error("Save failed:", error); }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Permanently delete this clinical record?")) return;
    try {
      const res = await fetch('/api/patients', {
        method: 'DELETE', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ id }),
      });
      if (res.ok) { await fetchData(); setShowNotification(true); setTimeout(() => setShowNotification(false), 2000); }
    } catch (error) { console.error("Delete failed:", error); }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] text-slate-900 pb-12 font-sans selection:bg-indigo-100">
      
      {showNotification && (
        <div className="fixed top-24 right-8 z-[60] bg-indigo-600 text-white px-6 py-4 rounded-2xl shadow-2xl flex items-center gap-3 animate-bounce border-4 border-indigo-400">
          <CheckCircle2 className="w-6 h-6" />
          <span className="font-black uppercase tracking-tight text-sm">Database Synchronized</span>
        </div>
      )}

      <nav className="bg-white/80 backdrop-blur-md border-b-4 border-slate-100 sticky top-0 z-40 px-8 py-4 flex justify-between items-center">
        <div className="flex items-center gap-3">
          <div className="bg-indigo-600 p-2 rounded-xl shadow-lg shadow-indigo-100"><Activity className="text-white w-6 h-6" /></div>
          <span className="text-2xl font-black tracking-tighter text-indigo-950 uppercase">MEDIFLOW</span>
        </div>
        <button onClick={() => { setEditingId(null); setActiveModal('new-patient'); }} className="bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-3 rounded-2xl font-black transition-all flex items-center gap-2 shadow-xl shadow-indigo-100 active:scale-95 border-b-4 border-indigo-800">
          <Plus className="w-5 h-5" /> NEW ADMISSION
        </button>
      </nav>

      <main className="max-w-6xl mx-auto mt-12 px-6">
        <header className="mb-10">
          <h1 className="text-5xl font-black text-slate-900 tracking-tight">Command Center</h1>
          <p className="text-slate-400 font-bold uppercase tracking-[0.3em] text-xs mt-2">Hospital Oversight & Real-time Vitals</p>
        </header>

        {/* --- DYNAMIC STATS GRID --- */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
          {derivedStats.map((stat) => (
            <div key={stat.id} className="bg-white p-8 rounded-[2.5rem] border-4 border-slate-100 shadow-sm transition-all hover:border-indigo-500 group">
              <div className={`p-4 rounded-2xl w-fit bg-${stat.color}-50 text-${stat.color}-600`}>{stat.icon}</div>
              <p className="text-slate-400 font-black text-[10px] uppercase tracking-[0.2em] mt-8">{stat.title}</p>
              <p className={`text-4xl font-black text-slate-900 mt-1 truncate ${stat.id === 'ward-stat' ? 'text-2xl pt-2' : ''}`}>
                {isLoading ? "..." : stat.count}
              </p>
              <p className="text-[10px] font-bold text-slate-300 uppercase mt-1">{stat.sub}</p>
            </div>
          ))}
        </div>

        {/* Live Table */}
        <div className="bg-white rounded-[3rem] border-4 border-slate-100 shadow-xl overflow-hidden">
          <div className="p-8 border-b-4 border-slate-50 flex justify-between items-center bg-slate-50/30">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 bg-emerald-500 rounded-full animate-pulse shadow-[0_0_10px_rgba(16,185,129,0.8)]" />
              <h3 className="font-black text-slate-800 uppercase tracking-widest text-sm">Active In-Patients</h3>
            </div>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead>
                <tr className="text-slate-400 text-[10px] uppercase tracking-[0.2em] font-black border-b">
                  <th className="px-8 py-6">Patient Identity</th>
                  <th className="px-8 py-6">Location</th>
                  <th className="px-8 py-6">Quick Vitals</th>
                  <th className="px-8 py-6 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {patientsList.map((p, i) => (
                  <tr key={i} className="hover:bg-indigo-50/50 transition-colors group">
                    <td className="px-8 py-6">
                      <div className="flex items-center gap-4">
                        <div className="w-12 h-12 rounded-2xl bg-slate-100 flex items-center justify-center font-black text-slate-500 group-hover:bg-indigo-600 group-hover:text-white transition-all border-2 border-slate-200">{p.name[0]}</div>
                        <div>
                          <p className="font-black text-slate-800 leading-none mb-1">{p.name}</p>
                          <p className="text-[10px] font-bold text-slate-400 uppercase">{p.age}Y • {p.gender} • {p.bloodGroup}</p>
                        </div>
                      </div>
                    </td>
                    <td className="px-8 py-6 font-bold text-slate-600 text-sm italic">{p.ward}</td>
                    <td className="px-8 py-6">
                      <div className="flex gap-2">
                        <span className="px-2 py-1 bg-rose-50 text-rose-600 rounded-lg text-[10px] font-black border border-rose-100">{p.vitals?.bp}</span>
                        <span className="px-2 py-1 bg-blue-50 text-blue-600 rounded-lg text-[10px] font-black border border-blue-100">{p.vitals?.spO2}%</span>
                      </div>
                    </td>
                    <td className="px-8 py-6 text-right">
                      <div className="flex justify-end gap-2">
                        <button onClick={() => startEdit(p)} className="bg-slate-100 text-slate-600 p-2.5 rounded-xl hover:bg-amber-100 transition-all border-2 border-transparent hover:border-amber-200"><Edit3 size={16} /></button>
                        <button onClick={() => handleDelete(p._id)} className="bg-slate-100 text-slate-600 p-2.5 rounded-xl hover:bg-rose-100 transition-all border-2 border-transparent hover:border-rose-200"><Trash2 size={16} /></button>
                        <button onClick={() => setSelectedPatient(p)} className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-[10px] font-black hover:bg-indigo-600 transition-all uppercase tracking-widest shadow-lg shadow-slate-200">Open File</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </main>

      {/* --- MODAL: NEW / EDIT PATIENT (Includes Gender & Ward) --- */}
      {activeModal === 'new-patient' && (
        <Modal title={editingId ? "Modify Clinical Record" : "Patient Intake Protocol"} onClose={() => {setActiveModal(null); setEditingId(null);}}>
          <div className="grid grid-cols-2 gap-6">
            <div className="col-span-2 space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Full Legal Name</label>
              <input type="text" value={formData.name} onChange={(e)=>setFormData({...formData, name: e.target.value})} className="w-full bg-slate-50 p-4 rounded-2xl border-2 border-slate-100 focus:border-indigo-500 outline-none font-bold" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Age</label>
              <input type="number" value={formData.age} onChange={(e)=>setFormData({...formData, age: e.target.value})} className="w-full bg-slate-50 p-4 rounded-2xl border-2 border-slate-100 outline-none font-bold" />
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Gender</label>
              <select value={formData.gender} onChange={(e)=>setFormData({...formData, gender: e.target.value})} className="w-full bg-slate-50 p-4 rounded-2xl border-2 border-slate-100 outline-none font-bold">
                {['Male', 'Female', 'Other'].map(g => <option key={g}>{g}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Blood Group</label>
              <select value={formData.bloodGroup} onChange={(e)=>setFormData({...formData, bloodGroup: e.target.value})} className="w-full bg-slate-50 p-4 rounded-2xl border-2 border-slate-100 outline-none font-bold">
                {['A+', 'A-', 'B+', 'B-', 'O+', 'O-', 'AB+', 'AB-'].map(bg => <option key={bg}>{bg}</option>)}
              </select>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Ward Location</label>
              <select value={formData.ward} onChange={(e)=>setFormData({...formData, ward: e.target.value})} className="w-full bg-slate-50 p-4 rounded-2xl border-2 border-slate-100 outline-none font-bold">
                {['Ward A (ICU)', 'Ward B (General)', 'Ward C (Pediatrics)', 'ER Cabin 1'].map(w => <option key={w}>{w}</option>)}
              </select>
            </div>
            <div className="col-span-2 pt-4 border-t-4 border-slate-50">
              <h4 className="text-[10px] font-black text-indigo-600 uppercase tracking-widest mb-4">Vitals Synchronized</h4>
              <div className="grid grid-cols-4 gap-4">
                {[{l:'Temp',k:'temp'},{l:'BP',k:'bp'},{l:'Pulse',k:'pulse'},{l:'SpO2',k:'spO2'}].map((v) => (
                  <div key={v.k}>
                    <label className="text-[8px] font-black text-slate-400 uppercase mb-1 block">{v.l}</label>
                    <input className="w-full bg-slate-50 p-3 rounded-xl border-2 border-slate-100 font-black text-xs" value={(formData as any)[v.k]} onChange={(e)=>setFormData({...formData, [v.k]: e.target.value})} />
                  </div>
                ))}
              </div>
            </div>
            <button onClick={handleSave} className="col-span-2 bg-indigo-600 text-white py-5 rounded-3xl font-black text-lg border-b-4 border-indigo-900 shadow-2xl">
              {editingId ? "Update & Sync Record" : "Confirm Admission & Sync"}
            </button>
          </div>
        </Modal>
      )}

      {/* --- MODAL: PATIENT FILE --- */}
      {selectedPatient && (
        <Modal title={`Medical File: ${selectedPatient.name}`} onClose={() => setSelectedPatient(null)}>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="col-span-2 grid grid-cols-4 gap-4">
              {[
                { label: 'Temp', val: selectedPatient.vitals?.temp + '°F', icon: <Thermometer />, color: 'orange' },
                { label: 'BP', val: selectedPatient.vitals?.bp, icon: <Activity />, color: 'rose' },
                { label: 'Pulse', val: selectedPatient.vitals?.pulse + ' bpm', icon: <HeartPulse />, color: 'emerald' },
                { label: 'SpO2', val: selectedPatient.vitals?.spO2 + '%', icon: <Wind />, color: 'blue' },
              ].map((v, i) => (
                <div key={i} className={`bg-${v.color}-50/50 p-5 rounded-[2rem] border-4 border-${v.color}-100 transition-transform hover:scale-105`}>
                  <div className={`flex items-center gap-2 mb-2 text-${v.color}-600`}>
                    {React.cloneElement(v.icon as React.ReactElement<any>, { size: 16 })}
                    <span className="text-[10px] font-black uppercase tracking-widest">{v.label}</span>
                  </div>
                  <p className="text-2xl font-black text-slate-900">{v.val || '--'}</p>
                </div>
              ))}
            </div>
            <div className="bg-slate-50 p-6 rounded-[2.5rem] border-4 border-slate-100 space-y-4">
                <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Clinical Profile</h4>
                <div className="flex justify-between items-center text-sm font-bold"><span className="text-slate-500">Age / Gender</span> <span>{selectedPatient.age}Y / {selectedPatient.gender}</span></div>
                <div className="flex justify-between items-center text-sm font-bold"><span className="text-slate-500">Blood Type</span> <span className="text-rose-600">{selectedPatient.bloodGroup}</span></div>
            </div>
            <div className="bg-amber-50 p-6 rounded-[2.5rem] border-4 border-amber-100">
                <div className="flex items-center gap-3 mb-2"><AlertCircle className="text-amber-600 w-4 h-4" /><p className="font-black text-amber-900 text-[10px] uppercase">Safety Alerts</p></div>
                <p className="text-xs font-bold text-amber-800/60 leading-relaxed">Check vitals every 4 hours. Ensure patient comfort in {selectedPatient.ward}.</p>
            </div>
          </div>
        </Modal>
      )}
    </div>
  );
};

export default HMSOnePage;