import HMSOnePage from "./HMSOnePage";

export default function Page() {
  return <HMSOnePage />;
}
