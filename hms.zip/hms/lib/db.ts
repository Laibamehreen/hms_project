import mongoose from 'mongoose';

const MONGODB_URI = process.env.MONGODB_URI!;

export const connectDB = async () => {
    if (mongoose.connection.readyState >= 1) return;
    return mongoose.connect(MONGODB_URI);
};

const PatientSchema = new mongoose.Schema({
    name: { type: String, required: true },
    status: { type: String, default: 'In-Patient' },
    admissionType: String,
    ward: String,
    age: Number,
    gender: String,
    bloodGroup: String,
    vitals: {
        temp: String,
        bp: String,
        pulse: String,
        spO2: String
    },
    medicalHistory: {
        allergies: [String],
        currentMedications: [String],
        pastConditions: [String]
    }
}, { timestamps: true });

export const Patient = mongoose.models.Patient || mongoose.model('Patient', PatientSchema);